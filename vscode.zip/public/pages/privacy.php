<!-- Privacy Policy -->
<section class="ptb50">
	<div class="container">
		<div class="row">
			<div class="col-12 text-justify">
				<p>PropLive has taken all reasonable steps to ensure that all the information on this website is authentic. Users are advised to research independently the credential of the advertisers provided on this website. PropLive shall not have any responsibility for the same.</p>
				<p>1. A user always has the option of not providing the information which is not mandatory</p>
				<p>2. In order to provide a personalized browsing experience, we may collect personal information from you. Also, we may require you to complete a registration form or ask for some information seeking your preferences regarding the property you are looking for. Based on your preferences, we will be able to deliver or allow you to access the most relevant information that meets your end.</p>
				<p>3. To extend this personalized experience we may track the IP address of a User's computer / device and save certain information on your system in the form of cookies. A User has the option of accepting or declining the cookies of this website by changing the settings of your browser.</p>
				<p>4. All PropLive website fully comply with all Indian Laws applicable. PropLive has always cooperated with all law enforcement inquires</p>
			</div>
		</div>
	</div>
</section>
