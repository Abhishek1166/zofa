<!-- disclaimer -->
<section class="ptb50">
	<div class="container">
		<div class="row">
			<div class="col-12 text-justify">
				<p>This website may contain links to other websites or videos that may belong to, and/or hosted, and/or operated by parties other than PropLive, for instance, the videos hosted by our third party service provider's server. PropLive is not responsible for the contents of any nature (including any related advertisements or videos) offered by any such linked website, or any link in a website, or any change to such websites, irrespective of whether these websites are operated by affiliates of PropLiveor other third parties. Inclusion of such a link on this website does not imply that PropLiveendorses the quality or the nature of content of the website linked from Proplive.in</p>

				<p>This website may contain information sourced from third parties. Proplive.in is not responsible for the information or content offered by such third parties. The inclusion of such information on the website does not imply that Proplive.in is responsible for the quality or the nature of the information provided by third parties.</p>

				<p>By agreeing to list a property or requirement at Proplive.in or responding to and advertising on Proplive.in, or by using the services of Proplive.in, the user hereby acknowledges and allows Proplive.in, its partners and other users of the site to get in touch with him/her from time to time for intimating them on events, potential buyers, tenants or properties they might be interested in. This could include offers to upgrade to premium service, information, as well as promotions.</p>

				<p>Proplive.in can use the user's email address and/or contact numbers for this purpose even if the user has registered with the "National Do Not Call Registry", overriding such DND registrations.</p>
			</div>
		</div>
	</div>
</section>
