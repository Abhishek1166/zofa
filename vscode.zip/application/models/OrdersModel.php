<?php defined('BASEPATH') or exit('No direct script access allowed');

class OrdersModel extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
        //Do your magic here
        $this->load->database();
        $this->tableName = 'orders';
    }
}

/* End of file OrdersModel.php */
